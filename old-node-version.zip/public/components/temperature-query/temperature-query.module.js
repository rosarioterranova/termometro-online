const temperatureQuery = angular.module('temperatureQuery', [])

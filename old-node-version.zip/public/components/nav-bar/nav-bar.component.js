navBar.component("navBar", {
    templateUrl: "components/nav-bar/nav-bar.template.html"
})

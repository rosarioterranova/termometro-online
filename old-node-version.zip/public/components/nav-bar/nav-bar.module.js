const navBar = angular.module('navBar', [])

const termometro = angular.module('termometro', [
    "ngRoute",
    "navBar",
    "temperatureQuery"
]) 
